def test_version():
    import greybox

    assert greybox.__version__ == "1.0.0"
